import pandas as pd
from data import DataPipeline
from matching import ProfileMatcher

def main():
    print("Welcome to the Profile Matching Algorithm Demo!")

    # Initialize components
    data_pipeline = DataPipeline()
    initial_weights = {'text_similarity': 0.5, 'mbti_match': 0.3, 'location_match': 0.2}
    matcher = ProfileMatcher(initial_weights=initial_weights)

    users_df = pd.DataFrame()
    current_user_id = None

    while True:
        print("\n--- Main Menu ---")
        print("1. Generate Synthetic User Data")
        print("2. Select User (to find matches for)")
        print("3. Show Top 5 Matches for Selected User")
        print("4. Simulate Feedback for a Match")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            num_users = int(input("Enter number of users to generate (e.g., 50): "))
            users_df = data_pipeline.generate_synthetic_data(num_users=num_users)
            matcher.preprocess_and_vectorize_all_users(users_df.copy())
            print(f"Generated {num_users} users and preprocessed their profiles.")

        elif choice == '2':
            if users_df.empty:
                print("Please generate user data first (Option 1).")
                continue
            print("Available User IDs:" + str(users_df['user_id'].tolist()))
            try:
                selected_id = int(input("Enter User ID to select: "))
                if selected_id in users_df['user_id'].tolist():
                    current_user_id = selected_id
                    print(f"User {current_user_id} selected.")
                else:
                    print("Invalid User ID.")
            except ValueError:
                print("Invalid input. Please enter a number.")

        elif choice == '3':
            if current_user_id is None:
                print("Please select a user first (Option 2).")
                continue
            if users_df.empty:
                print("Please generate user data first (Option 1).")
                continue

            print(f"\nFinding top 5 matches for User ID: {current_user_id}...")
            top_matches = matcher.get_top_matches(current_user_id, users_df.copy(), num_matches=5)
            if not top_matches.empty:
                print(f"\nTop 5 Matches for User {current_user_id}:")
                print(top_matches)
            else:
                print("No matches found.")

        elif choice == '4':
            if current_user_id is None:
                print("Please select a user first (Option 2).")
                continue
            if users_df.empty:
                print("Please generate user data first (Option 1).")
                continue
            if matcher.feedback_manager.model is None or len(matcher.feedback_manager.feedback_data) < 2:
                 print("Not enough feedback yet to train the model. Please provide more feedback.")

            match_id_str = input(f"Enter the User ID of the match you want to give feedback on for User {current_user_id}: ")
            try:
                match_id = int(match_id_str)
                if match_id == current_user_id or match_id not in users_df['user_id'].tolist():
                    print("Invalid Match User ID.")
                    continue

                user_profile_a = users_df[users_df['user_id'] == current_user_id].iloc[0].to_dict()
                user_profile_b = users_df[users_df['user_id'] == match_id].iloc[0].to_dict()

                # Recalculate component scores to record feedback accurately
                vector_a = matcher.user_vectors.get(user_profile_a['user_id'])
                vector_b = matcher.user_vectors.get(user_profile_b['user_id'])
                text_similarity = matcher.text_analyzer.calculate_similarity(vector_a, vector_b) * 100
                mbti_score = matcher.score_calculator.get_mbti_score(user_profile_a['mbti_type'], user_profile_b['mbti_type'])
                location_match = 100 if user_profile_a['location'] == user_profile_b['location'] else 0

                feedback = input("Did you accept this match? (yes/no): ").lower()
                accepted = 1 if feedback == 'yes' else 0

                matcher.record_feedback_and_adjust_weights(text_similarity, mbti_score, location_match, accepted)
                print(f"Feedback recorded for match {match_id}. Weights may have been adjusted.")

            except ValueError:
                print("Invalid input. Please enter a number.")

        elif choice == '5':
            print("Exiting the application. Goodbye!")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
