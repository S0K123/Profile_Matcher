class ScoreCalculator:
    def __init__(self, weights=None):
        # Default weights. These will be dynamically adjusted by the feedback loop.
        self.weights = weights if weights else {'text_similarity': 0.5, 'mbti_match': 0.3, 'location_match': 0.2}

        # MBTI compatibility matrix (simplified example)
        # This can be expanded with more nuanced scoring based on actual MBTI compatibility research
        self.mbti_compatibility = {
            'INTJ': {'ENFP': 100, 'ENTP': 80, 'INTP': 70, 'ISTJ': 50},
            'ENFP': {'INTJ': 100, 'INFJ': 90, 'ENTP': 70, 'ESFP': 40},
            'ENTP': {'INTJ': 80, 'ENFP': 70, 'INTP': 90, 'ISTP': 60},
            'INTP': {'ENTP': 90, 'INTJ': 70, 'INFP': 85, 'ISTP': 70},
            # ... add more MBTI types and their compatibilities
        }

    def get_mbti_score(self, mbti_user_a, mbti_user_b):
        """
        Calculates a score based on MBTI compatibility.
        Returns 0 if no direct compatibility is defined, allowing for expansion.
        """
        score = self.mbti_compatibility.get(mbti_user_a, {}).get(mbti_user_b, 0)
        # Also check the reverse for symmetric compatibility
        if score == 0:
            score = self.mbti_compatibility.get(mbti_user_b, {}).get(mbti_user_a, 0)
        return score

    def calculate_total_score(self, text_similarity, mbti_user_a, mbti_user_b, location_user_a, location_user_b):
        """
        Combines text similarity, MBTI score, and location data into a single compatibility score.
        """
        mbti_score = self.get_mbti_score(mbti_user_a, mbti_user_b)

        # Simple location matching: 100 if same city/region, 0 otherwise. Can be expanded with geographical distance.
        location_match = 100 if location_user_a == location_user_b else 0

        total_score = (
            self.weights['text_similarity'] * text_similarity +
            self.weights['mbti_match'] * mbti_score +
            self.weights['location_match'] * location_match
        )
        return total_score

    def update_weights(self, new_weights):
        """
        Updates the weights for the scoring algorithm. Used by the feedback loop.
        """
        self.weights.update(new_weights)

# Example Usage (for testing purposes)
if __name__ == "__main__":
    scorer = ScoreCalculator()

    # Sample data
    text_sim_score = 0.75  # from NLP module
    mbti_u1 = 'INTJ'
    mbti_u2 = 'ENFP'
    mbti_u3 = 'ISTP'
    loc_u1 = 'New York'
    loc_u2 = 'New York'
    loc_u3 = 'Los Angeles'

    # Calculate scores
    score1_2 = scorer.calculate_total_score(text_sim_score, mbti_u1, mbti_u2, loc_u1, loc_u2)
    score1_3 = scorer.calculate_total_score(text_sim_score, mbti_u1, mbti_u3, loc_u1, loc_u3)

    print(f"Compatibility Score (INTJ, ENFP, Same Location): {score1_2:.2f}")
    print(f"Compatibility Score (INTJ, ISTP, Different Location): {score1_3:.2f}")

    # Simulate weight update
    new_weights = {'text_similarity': 0.6, 'mbti_match': 0.2, 'location_match': 0.2}
    scorer.update_weights(new_weights)
    print(f"\nUpdated weights: {scorer.weights}")

    score1_2_updated = scorer.calculate_total_score(text_sim_score, mbti_u1, mbti_u2, loc_u1, loc_u2)
    print(f"Compatibility Score (INTJ, ENFP, Same Location) with updated weights: {score1_2_updated:.2f}")
