import pandas as pd
from typing import List, Dict, Any
import numpy as np
from nlp import TextAnalyzer, AdvancedNLPTools
from matching import ScoreCalculator
from feedback_loop import FeedbackManager
from sklearn.metrics.pairwise import cosine_similarity

class ProfileMatcher:
    def __init__(self, initial_weights=None, nlp_backend: str = 'tfidf'):
        self.nlp_backend = nlp_backend.lower()
        self.text_analyzer = TextAnalyzer() # NLTK + TF-IDF
        self.advanced_nlp_tools = AdvancedNLPTools() # spaCy + Sentence Transformers
        self.score_calculator = ScoreCalculator(weights=initial_weights)
        self.feedback_manager = FeedbackManager(initial_weights if initial_weights else self.score_calculator.weights)
        self.user_vectors = {}

        if self.nlp_backend not in ['tfidf', 'spacy', 'sentencetransformers']:
            raise ValueError("Invalid NLP backend. Choose from 'tfidf', 'spacy', 'sentencetransformers'.")

    def _get_text_vector(self, text: str) -> Any:
        """
        Internal method to get a text vector based on the selected NLP backend.
        """
        if self.nlp_backend == 'tfidf':
            # TF-IDF requires fitting first, so this will only work if vectorizer is fitted
            if not self.text_analyzer.vectorizer.vocabulary_:
                raise ValueError("TF-IDF vectorizer not fitted. Call preprocess_and_vectorize_all_users first.")
            return self.text_analyzer.vectorize_text(self.text_analyzer.preprocess_text(text))
        elif self.nlp_backend == 'spacy':
            return self.advanced_nlp_tools.spacy_preprocess_and_vectorize(text)
        elif self.nlp_backend == 'sentencetransformers':
            return self.advanced_nlp_tools.sentence_transformer_vectorize(text)
        return None

    def preprocess_and_vectorize_all_users(self, users_df: pd.DataFrame):
        """
        Preprocesses and vectorizes the 'about_me' and 'professional_summary' for all users
        using the selected NLP backend. Stores the combined vector for each user.
        """
        print(f"Preprocessing and vectorizing all users with {self.nlp_backend} backend...")
        users_df['combined_text'] = users_df['about_me'] + " " + users_df['professional_summary']
        
        if self.nlp_backend == 'tfidf':
            preprocessed_texts = [self.text_analyzer.preprocess_text(text) for text in users_df['combined_text']]
            self.text_analyzer.vectorizer = self.text_analyzer.vectorizer.fit(preprocessed_texts) # Fit TF-IDF once
            for _, row in users_df.iterrows():
                preprocessed_text = self.text_analyzer.preprocess_text(row['combined_text'])
                self.user_vectors[row['user_id']] = self.text_analyzer.vectorize_text(preprocessed_text)
        elif self.nlp_backend == 'spacy':
            for _, row in users_df.iterrows():
                self.user_vectors[row['user_id']] = self.advanced_nlp_tools.spacy_preprocess_and_vectorize(row['combined_text'])
        elif self.nlp_backend == 'sentencetransformers':
            for _, row in users_df.iterrows():
                self.user_vectors[row['user_id']] = self.advanced_nlp_tools.sentence_transformer_vectorize(row['combined_text'])
        
        print("All user texts preprocessed and vectorized.")


    def calculate_text_similarity(self, vector1: Any, vector2: Any) -> float:
        """
        Calculates cosine similarity between two vectors.
        Handles different vector types (sparse for TF-IDF, dense for spaCy/ST).
        """
        if vector1 is None or vector2 is None:
            return 0.0

        # Ensure vectors are in a format compatible with cosine_similarity
        # TF-IDF returns sparse matrices, spaCy/ST return numpy arrays (dense)
        if hasattr(vector1, 'todense'): # Check if it's a sparse matrix
            vector1 = vector1.todense()
        if hasattr(vector2, 'todense'):
            vector2 = vector2.todense()
            
        # Reshape to 2D arrays if they are 1D numpy arrays
        if isinstance(vector1, np.ndarray) and vector1.ndim == 1:
            vector1 = vector1.reshape(1, -1)
        if isinstance(vector2, np.ndarray) and vector2.ndim == 1:
            vector2 = vector2.reshape(1, -1)

        similarity = cosine_similarity(vector1, vector2)[0][0]
        return float(similarity * 100) # Scale to 0-100


    def get_compatibility_score(self, user_profile_a, user_profile_b) -> float:
        """
        Calculates the compatibility score between two user profiles.
        user_profile_a and user_profile_b are dictionaries containing user data.
        """
        # 1. NLP & Semantic Analysis
        vector_a = self.user_vectors.get(user_profile_a['user_id'])
        vector_b = self.user_vectors.get(user_profile_b['user_id'])

        if vector_a is None or vector_b is None:
            # If vectors are missing, generate them on the fly
            combined_text_a = user_profile_a['about_me'] + " " + user_profile_a['professional_summary']
            combined_text_b = user_profile_b['about_me'] + " " + user_profile_b['professional_summary']
            vector_a = self._get_text_vector(combined_text_a)
            vector_b = self._get_text_vector(combined_text_b)
            if vector_a is None or vector_b is None:
                raise ValueError("Could not generate text vectors for one or both users.")

            # Cache on-the-fly generated vectors for future use
            self.user_vectors[user_profile_a['user_id']] = vector_a
            self.user_vectors[user_profile_b['user_id']] = vector_b

        text_similarity = self.calculate_text_similarity(vector_a, vector_b) # Scale to 0-100 already

        # 2. Profile Scoring Engine
        mbti_user_a = user_profile_a['mbti_type']
        mbti_user_b = user_profile_b['mbti_type']
        location_user_a = user_profile_a['location']
        location_user_b = user_profile_b['location']

        total_score = (
            self.score_calculator.calculate_total_score(
            text_similarity,
            mbti_user_a,
            mbti_user_b,
            location_user_a,
            location_user_b,
            self.feedback_manager.get_current_weights() # Pass current weights
        ))
        return total_score

    def record_feedback_and_adjust_weights(self, text_similarity, mbti_score, location_match, accepted):
        """
        Records user feedback and potentially adjusts the scoring weights.
        """
        self.feedback_manager.record_feedback(text_similarity, mbti_score, location_match, accepted)
        # Adjust weights only after a certain number of feedbacks (e.g., 5) for demonstration
        if len(self.feedback_manager.feedback_data) % 5 == 0:
            self.feedback_manager.train_model()
            self.feedback_manager.adjust_weights() # This updates the weights in feedback_manager
            self.score_calculator.update_weights(self.feedback_manager.get_current_weights()) # Update score_calculator

    def get_top_matches(self, user_id, all_users_df, num_matches=5) -> pd.DataFrame:
        """
        Finds the top N compatibility matches for a given user.
        """
        user_profile = all_users_df[all_users_df['user_id'] == user_id].iloc[0].to_dict()
        potential_matches = all_users_df[all_users_df['user_id'] != user_id].to_dict(orient='records')

        scores = []
        for match_profile in potential_matches:
            try:
                score = self.get_compatibility_score(user_profile, match_profile)
                scores.append({'user_id': match_profile['user_id'], 'name': match_profile['name'], 'score': score})
            except ValueError as e:
                print(f"Error calculating score for user {match_profile['user_id']}: {e}")
                continue

        scores_df = pd.DataFrame(scores)
        if not scores_df.empty:
            top_matches = scores_df.sort_values(by='score', ascending=False).head(num_matches)
            return top_matches
        return pd.DataFrame()

# Example Usage (for testing purposes)
if __name__ == "__main__":
    from data import DataPipeline

    # 1. Generate synthetic user data
    data_pipeline = DataPipeline()
    users_df = data_pipeline.generate_synthetic_data(num_users=20)

    # 2. Initialize the matcher with default weights, using different NLP backends
    initial_weights = {'text_similarity': 0.5, 'mbti_match': 0.3, 'location_match': 0.2}

    print("\n--- TF-IDF Backend Demo ---")
    matcher_tfidf = ProfileMatcher(initial_weights=initial_weights, nlp_backend='tfidf')
    matcher_tfidf.preprocess_and_vectorize_all_users(users_df.copy())
    user1 = users_df[users_df['user_id'] == 1].iloc[0].to_dict()
    user2 = users_df[users_df['user_id'] == 2].iloc[0].to_dict()
    score_tfidf = matcher_tfidf.get_compatibility_score(user1, user2)
    print(f"Compatibility Score (TF-IDF) between {user1['name']} and {user2['name']}: {score_tfidf:.2f}")

    print("\n--- spaCy Backend Demo ---")
    matcher_spacy = ProfileMatcher(initial_weights=initial_weights, nlp_backend='spacy')
    matcher_spacy.preprocess_and_vectorize_all_users(users_df.copy())
    score_spacy = matcher_spacy.get_compatibility_score(user1, user2)
    print(f"Compatibility Score (spaCy) between {user1['name']} and {user2['name']}: {score_spacy:.2f}")

    print("\n--- Sentence Transformers Backend Demo ---")
    matcher_st = ProfileMatcher(initial_weights=initial_weights, nlp_backend='sentencetransformers')
    matcher_st.preprocess_and_vectorize_all_users(users_df.copy())
    score_st = matcher_st.get_compatibility_score(user1, user2)
    print(f"Compatibility Score (Sentence Transformers) between {user1['name']} and {user2['name']}: {score_st:.2f}")
