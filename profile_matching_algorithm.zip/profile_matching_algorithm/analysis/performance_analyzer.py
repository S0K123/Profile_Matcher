import pandas as pd
import numpy as np
import random
from matching import ProfileMatcher
from data import DataPipeline

class PerformanceAnalyzer:
    def __init__(self, initial_weights):
        self.initial_weights = initial_weights
        self.matcher = ProfileMatcher(initial_weights=initial_weights.copy())
        self.data_pipeline = DataPipeline()
        self.performance_log = []

    def simulate_feedback_loop(self, num_users, num_iterations, feedbacks_per_iteration=5):
        """
        Simulates the feedback loop over multiple iterations and logs performance.
        """
        print(f"Simulating feedback loop for {num_iterations} iterations with {num_users} users.")
        users_df = self.data_pipeline.generate_synthetic_data(num_users=num_users)
        self.matcher.preprocess_and_vectorize_all_users(users_df.copy())

        for iteration in range(num_iterations):
            print(f"\n--- Iteration {iteration + 1}/{num_iterations} ---")
            acceptance_count = 0
            total_feedback_given = 0

            for _ in range(feedbacks_per_iteration):
                # Randomly pick a user and a potential match
                user_id = random.choice(users_df['user_id'].tolist())
                potential_matches_df = users_df[users_df['user_id'] != user_id]
                if potential_matches_df.empty:
                    continue
                match_id = random.choice(potential_matches_df['user_id'].tolist())

                user_profile_a = users_df[users_df['user_id'] == user_id].iloc[0].to_dict()
                user_profile_b = users_df[users_df['user_id'] == match_id].iloc[0].to_dict()

                # Calculate component scores for feedback recording
                vector_a = self.matcher.user_vectors.get(user_profile_a['user_id'])
                vector_b = self.matcher.user_vectors.get(user_profile_b['user_id'])
                text_similarity = self.matcher.text_analyzer.calculate_similarity(vector_a, vector_b) * 100
                mbti_score = self.matcher.score_calculator.get_mbti_score(user_profile_a['mbti_type'], user_profile_b['mbti_type'])
                location_match = 100 if user_profile_a['location'] == user_profile_b['location'] else 0

                # Simulate acceptance based on a simple rule for demonstration (e.g., higher score -> more likely to accept)
                # In a real scenario, this would come from actual user interaction data
                current_total_score = self.matcher.get_compatibility_score(user_profile_a, user_profile_b)
                # A simple probabilistic model for acceptance: higher score -> higher chance of acceptance
                acceptance_probability = min(1.0, max(0.0, current_total_score / 100.0))
                accepted = 1 if random.random() < acceptance_probability else 0

                self.matcher.record_feedback_and_adjust_weights(text_similarity, mbti_score, location_match, accepted)
                total_feedback_given += 1
                if accepted == 1:
                    acceptance_count += 1

            if total_feedback_given > 0:
                acceptance_rate = (acceptance_count / total_feedback_given) * 100
                self.performance_log.append({
                    'iteration': iteration + 1,
                    'acceptance_rate': acceptance_rate,
                    'weights': self.matcher.score_calculator.weights.copy()
                })
                print(f"Iteration {iteration + 1} - Acceptance Rate: {acceptance_rate:.2f}%")
            else:
                print(f"Iteration {iteration + 1} - No feedback given.")

        print("Simulation complete.")
        return pd.DataFrame(self.performance_log)

    def generate_report(self, performance_df):
        """
        Generates a basic performance report.
        """
        print("\n--- Performance Report ---")
        if not performance_df.empty:
            initial_acceptance_rate = performance_df['acceptance_rate'].iloc[0]
            final_acceptance_rate = performance_df['acceptance_rate'].iloc[-1]
            print(f"Initial Acceptance Rate: {initial_acceptance_rate:.2f}%")
            print(f"Final Acceptance Rate: {final_acceptance_rate:.2f}%")
            print(f"Improvement: {final_acceptance_rate - initial_acceptance_rate:.2f}% points")

            print("\nAcceptance Rate over Iterations:")
            print(performance_df[['iteration', 'acceptance_rate']])

            print("\nWeights over Iterations:")
            for index, row in performance_df.iterrows():
                print(f"Iteration {row['iteration']}: {row['weights']}")

        else:
            print("No performance data to report.")

# Example Usage (for testing purposes)
if __name__ == "__main__":
    initial_weights_for_analysis = {'text_similarity': 0.5, 'mbti_match': 0.3, 'location_match': 0.2}
    analyzer = PerformanceAnalyzer(initial_weights=initial_weights_for_analysis)

    # Simulate the feedback loop over 10 iterations with 50 users
    performance_df = analyzer.simulate_feedback_loop(num_users=50, num_iterations=10, feedbacks_per_iteration=10)

    # Generate and print the performance report
    analyzer.generate_report(performance_df)
