import spacy
from sentence_transformers import SentenceTransformer
from typing import List, Dict, Any
import numpy as np

# Ensure spaCy model is downloaded
try:
    nlp_spacy = spacy.load("en_core_web_sm")
except OSError:
    print("Downloading spaCy model 'en_core_web_sm'...")
    spacy.cli.download("en_core_web_sm")
    nlp_spacy = spacy.load("en_core_web_sm")

# Load Sentence Transformer model (once)
sentence_model = SentenceTransformer('all-MiniLM-L6-v2')

class AdvancedNLPTools:
    def __init__(self):
        self.nlp_spacy = nlp_spacy
        self.sentence_model = sentence_model

    def spacy_preprocess_and_vectorize(self, text: str) -> np.ndarray:
        """
        Preprocesses text using spaCy and returns a document vector.
        """
        if not isinstance(text, str):
            return np.zeros(self.nlp_spacy.vocab.vectors.shape[1]) # Return zero vector for non-string
        doc = self.nlp_spacy(text.lower())
        # Remove stopwords and punctuation, and lemmatize
        processed_tokens = [token.lemma_ for token in doc if not token.is_stop and not token.is_punct and token.is_alpha]
        processed_text = " ".join(processed_tokens)
        # Re-vectorize the processed text. spaCy's doc.vector gives a mean vector of tokens.
        return self.nlp_spacy(processed_text).vector

    def sentence_transformer_vectorize(self, text: str) -> np.ndarray:
        """
        Generates semantic embeddings for text using Sentence Transformers.
        """
        if not isinstance(text, str):
            return np.zeros(self.sentence_model.get_sentence_embedding_dimension()) # Return zero vector
        return self.sentence_model.encode(text)

# Example Usage (for testing purposes)
if __name__ == "__main__":
    advanced_nlp = AdvancedNLPTools()

    sample_text_1 = "I am a software engineer passionate about artificial intelligence and machine learning."
    sample_text_2 = "Software developer with a strong interest in AI. I love coding and creating new applications."
    sample_text_3 = "An artist who loves painting and exploring different cultures."

    print("\n--- spaCy Processing ---")
    spacy_vec_1 = advanced_nlp.spacy_preprocess_and_vectorize(sample_text_1)
    spacy_vec_2 = advanced_nlp.spacy_preprocess_and_vectorize(sample_text_2)
    spacy_vec_3 = advanced_nlp.spacy_preprocess_and_vectorize(sample_text_3)
    print(f"spaCy vector 1 shape: {spacy_vec_1.shape}")
    print(f"spaCy vector 2 shape: {spacy_vec_2.shape}")
    # Note: For similarity, you'd use cosine_similarity on these vectors

    print("\n--- Sentence Transformers Processing ---")
    st_vec_1 = advanced_nlp.sentence_transformer_vectorize(sample_text_1)
    st_vec_2 = advanced_nlp.sentence_transformer_vectorize(sample_text_2)
    st_vec_3 = advanced_nlp.sentence_transformer_vectorize(sample_text_3)
    print(f"Sentence Transformer vector 1 shape: {st_vec_1.shape}")
    print(f"Sentence Transformer vector 2 shape: {st_vec_2.shape}")
    # Note: For similarity, you'd use cosine_similarity on these vectors
