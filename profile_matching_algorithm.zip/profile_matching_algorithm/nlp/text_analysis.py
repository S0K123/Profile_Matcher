import re
import string
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import nltk

# Ensure necessary NLTK data is downloaded
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)

class TextAnalyzer:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.stopwords = set(stopwords.words('english'))
        self.vectorizer = TfidfVectorizer()

    def preprocess_text(self, text):
        """
        Cleans raw text data by removing stopwords, punctuation, and performing lemmatization.
        """
        text = text.lower()
        text = re.sub(f'[{re.escape(string.punctuation)}]', '', text)
        words = text.split()
        words = [self.lemmatizer.lemmatize(word) for word in words if word not in self.stopwords]
        return " ".join(words)

    def vectorize_texts(self, texts):
        """
        Converts a list of cleaned texts into numerical TF-IDF vector embeddings.
        """
        return self.vectorizer.fit_transform(texts)

    def calculate_similarity(self, text_vector1, text_vector2):
        """
        Calculates the cosine similarity between two text vectors.
        """
        # Reshape the input to be 2D arrays if they are 1D
        if text_vector1.ndim == 1:
            text_vector1 = text_vector1.reshape(1, -1)
        if text_vector2.ndim == 1:
            text_vector2 = text_vector2.reshape(1, -1)

        return cosine_similarity(text_vector1, text_vector2)[0][0]

# Example Usage (for testing purposes)
if __name__ == "__main__":
    analyzer = TextAnalyzer()

    # Sample bios
    bio1 = "I am a software engineer passionate about artificial intelligence and machine learning. I enjoy problem-solving and developing innovative solutions."
    bio2 = "Software developer with a strong interest in AI. I love coding and creating new applications that solve real-world problems."
    bio3 = "An artist who loves painting and exploring different cultures. I enjoy creative endeavors."

    print("Original Bio 1:", bio1)
    print("Original Bio 2:", bio2)
    print("Original Bio 3:", bio3)

    # Preprocess texts
    preprocessed_bio1 = analyzer.preprocess_text(bio1)
    preprocessed_bio2 = analyzer.preprocess_text(bio2)
    preprocessed_bio3 = analyzer.preprocess_text(bio3)

    print("\nPreprocessed Bio 1:", preprocessed_bio1)
    print("Preprocessed Bio 2:", preprocessed_bio2)
    print("Preprocessed Bio 3:", preprocessed_bio3)

    # Vectorize texts
    all_bios = [preprocessed_bio1, preprocessed_bio2, preprocessed_bio3]
    text_vectors = analyzer.vectorize_texts(all_bios)

    # Calculate similarity
    sim1_2 = analyzer.calculate_similarity(text_vectors[0], text_vectors[1])
    sim1_3 = analyzer.calculate_similarity(text_vectors[0], text_vectors[2])
    sim2_3 = analyzer.calculate_similarity(text_vectors[1], text_vectors[2])

    print(f"\nSimilarity between Bio 1 and Bio 2: {sim1_2:.2f}")
    print(f"Similarity between Bio 1 and Bio 3: {sim1_3:.2f}")
    print(f"Similarity between Bio 2 and Bio 3: {sim2_3:.2f}")
