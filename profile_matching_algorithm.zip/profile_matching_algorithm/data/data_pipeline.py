import pandas as pd
import numpy as np
from faker import Faker
import random

# Initialize Faker for generating fake data
fake = Faker()

class DataPipeline:
    def __init__(self):
        self.users_data = []

    def generate_mbti(self):
        types = ['ISTJ', 'ISFJ', 'INFJ', 'INTJ', 'ISTP', 'ISFP', 'INFP', 'INTP',
                 'ESTP', 'ESFP', 'ENFP', 'ENTP', 'ESTJ', 'ESFJ', 'ENFJ', 'ENTJ']
        return random.choice(types)

    def generate_user_profile(self, user_id):
        """
        Generates a single synthetic user profile.
        """
        return {
            'user_id': user_id,
            'name': fake.name(),
            'about_me': fake.paragraph(nb_sentences=5),
            'professional_summary': fake.catch_phrase() + ". " + fake.bs(),
            'mbti_type': self.generate_mbti(),
            'location': fake.city()
        }

    def generate_synthetic_data(self, num_users=100):
        """
        Generates a specified number of synthetic user profiles.
        """
        print(f"Generating {num_users} synthetic user profiles...")
        self.users_data = [self.generate_user_profile(i) for i in range(1, num_users + 1)]
        print("Data generation complete.")
        return pd.DataFrame(self.users_data)

    def get_user_data(self):
        """
        Returns the generated user data as a Pandas DataFrame.
        """
        return pd.DataFrame(self.users_data)

# Example Usage (for testing purposes)
if __name__ == "__main__":
    pipeline = DataPipeline()
    users_df = pipeline.generate_synthetic_data(num_users=10)
    print("\nGenerated User Data Head:")
    print(users_df.head())

    # In a real scenario, you would save/load this data
    # users_df.to_csv('users.csv', index=False)
