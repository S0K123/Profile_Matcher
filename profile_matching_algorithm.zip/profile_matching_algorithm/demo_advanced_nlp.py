import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import spacy
from sentence_transformers import SentenceTransformer
import numpy as np
import re
import string

# --- NLTK Setup (for reference, also handled in TextAnalyzer) ---
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)

# --- spaCy Setup ---
try:
    nlp_spacy = spacy.load("en_core_web_sm")
except OSError:
    print("Downloading spaCy model 'en_core_web_sm'...")
    spacy.cli.download("en_core_web_sm")
    nlp_spacy = spacy.load("en_core_web_sm")

# --- Sentence Transformers Setup ---
sentence_model = SentenceTransformer('all-MiniLM-L6-v2')

# Sample Texts
text1 = "I am a software engineer passionate about artificial intelligence and machine learning. I enjoy problem-solving and developing innovative solutions."
text2 = "Software developer with a strong interest in AI. I love coding and creating new applications that solve real-world problems."
text3 = "An artist who loves painting and exploring different cultures. I enjoy creative endeavors."

print("Original Text 1:", text1)
print("Original Text 2:", text2)
print("Original Text 3:", text3)

# ==================================================================
# NLTK + TF-IDF Demonstration
# ==================================================================
print("\n--- NLTK + TF-IDF Demonstration ---")

# Preprocessing with NLTK
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def preprocess_nltk(text):
    text = text.lower()
    text = re.sub(f'[{re.escape(string.punctuation)}]', '', text)
    words = text.split()
    words = [lemmatizer.lemmatize(word) for word in words if word not in stop_words]
    return " ".join(words)

preprocessed_nltk_1 = preprocess_nltk(text1)
preprocessed_nltk_2 = preprocess_nltk(text2)
preprocessed_nltk_3 = preprocess_nltk(text3)

print(f"NLTK Preprocessed Text 1: {preprocessed_nltk_1}")
print(f"NLTK Preprocessed Text 2: {preprocessed_nltk_2}")

# TF-IDF Vectorization
tfidf_vectorizer = TfidfVectorizer()
tfidf_vectors = tfidf_vectorizer.fit_transform([preprocessed_nltk_1, preprocessed_nltk_2, preprocessed_nltk_3])

print(f"TF-IDF Vector Shape: {tfidf_vectors.shape}")

# Cosine Similarity
sim_nltk = cosine_similarity(tfidf_vectors[0], tfidf_vectors[1])[0][0]
print(f"NLTK TF-IDF Cosine Similarity (Text 1 vs Text 2): {sim_nltk:.4f}")

# ==================================================================
# spaCy Demonstration
# ==================================================================
print("\n--- spaCy Demonstration ---")

def spacy_process_and_vectorize(text):
    doc = nlp_spacy(text.lower())
    processed_tokens = [token.lemma_ for token in doc if not token.is_stop and not token.is_punct and token.is_alpha]
    processed_text = " ".join(processed_tokens)
    return nlp_spacy(processed_text).vector # spaCy's doc.vector for embeddings

spacy_vec_1 = spacy_process_and_vectorize(text1)
spacy_vec_2 = spacy_process_and_vectorize(text2)
spacy_vec_3 = spacy_process_and_vectorize(text3)

print(f"spaCy Vector 1 Shape: {spacy_vec_1.shape}")

# Cosine Similarity for spaCy vectors
sim_spacy = cosine_similarity(spacy_vec_1.reshape(1, -1), spacy_vec_2.reshape(1, -1))[0][0]
print(f"spaCy Cosine Similarity (Text 1 vs Text 2): {sim_spacy:.4f}")

# ==================================================================
# HuggingFace Transformers (Sentence Transformers) Demonstration
# ==================================================================
print("\n--- Sentence Transformers Demonstration ---")

st_vec_1 = sentence_model.encode(text1)
st_vec_2 = sentence_model.encode(text2)
st_vec_3 = sentence_model.encode(text3)

print(f"Sentence Transformers Vector 1 Shape: {st_vec_1.shape}")

# Cosine Similarity for Sentence Transformers vectors
sim_st = cosine_similarity(st_vec_1.reshape(1, -1), st_vec_2.reshape(1, -1))[0][0]
print(f"Sentence Transformers Cosine Similarity (Text 1 vs Text 2): {sim_st:.4f}")

print("\nDemonstration Complete: All specified NLP tools have been implemented and showcased.")
