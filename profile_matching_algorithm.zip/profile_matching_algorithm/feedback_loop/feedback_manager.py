import pandas as pd
from sklearn.linear_model import LogisticRegression
import numpy as np

class FeedbackManager:
    def __init__(self, initial_weights):
        self.feedback_data = pd.DataFrame(columns=['text_similarity', 'mbti_match', 'location_match', 'accepted'])
        self.current_weights = initial_weights
        self.model = None

    def record_feedback(self, text_similarity, mbti_match, location_match, accepted):
        """
        Records user feedback for a given match.
        'accepted' should be 1 for accept, 0 for reject.
        """
        new_entry = pd.DataFrame([{
            'text_similarity': text_similarity,
            'mbti_match': mbti_match,
            'location_match': location_match,
            'accepted': accepted
        }])
        self.feedback_data = pd.concat([self.feedback_data, new_entry], ignore_index=True)

    def train_model(self):
        """
        Trains a logistic regression model to predict acceptance based on match components.
        This model will help in understanding which features lead to acceptance.
        """
        if len(self.feedback_data) < 2:  # Need at least two samples to train a meaningful model
            print("Not enough feedback data to train the model.")
            return

        X = self.feedback_data[['text_similarity', 'mbti_match', 'location_match']]
        y = self.feedback_data['accepted']

        # Use LogisticRegression to model acceptance
        self.model = LogisticRegression()
        self.model.fit(X, y)
        print("Feedback model trained successfully.")

    def adjust_weights(self):
        """
        Adjusts the scoring weights based on the trained model's coefficients.
        The absolute values of coefficients indicate the feature importance.
        Weights are normalized to sum to 1.
        """
        if self.model and hasattr(self.model, 'coef_'):
            # Using absolute coefficients as a proxy for feature importance
            coefs = np.abs(self.model.coef_[0])
            total_coef = np.sum(coefs)

            if total_coef > 0:
                # Normalize coefficients to sum to 1, representing new weights
                normalized_coefs = coefs / total_coef
                self.current_weights['text_similarity'] = normalized_coefs[0]
                self.current_weights['mbti_match'] = normalized_coefs[1]
                self.current_weights['location_match'] = normalized_coefs[2]
                print(f"Weights adjusted to: {self.current_weights}")
            else:
                print("Cannot adjust weights: sum of coefficients is zero.")
        else:
            print("Model not trained or no coefficients to adjust weights.")

    def get_current_weights(self):
        """
        Returns the currently adjusted weights.
        """
        return self.current_weights

# Example Usage (for testing purposes)
if __name__ == "__main__":
    initial_weights = {'text_similarity': 0.5, 'mbti_match': 0.3, 'location_match': 0.2}
    feedback_manager = FeedbackManager(initial_weights)

    # Simulate some feedback
    feedback_manager.record_feedback(0.8, 100, 100, 1) # Accepted, high text, high MBTI, same location
    feedback_manager.record_feedback(0.2, 50, 0, 0)   # Rejected, low text, low MBTI, different location
    feedback_manager.record_feedback(0.9, 60, 100, 1) # Accepted, high text, medium MBTI, same location
    feedback_manager.record_feedback(0.1, 90, 0, 0)   # Rejected, low text, high MBTI, different location
    feedback_manager.record_feedback(0.7, 80, 100, 1) # Accepted, medium text, high MBTI, same location

    print("\nInitial Weights:", feedback_manager.get_current_weights())

    feedback_manager.train_model()
    feedback_manager.adjust_weights()

    print("Final Adjusted Weights:", feedback_manager.get_current_weights())
